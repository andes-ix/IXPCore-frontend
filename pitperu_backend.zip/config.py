redis_config = {
    'host': 'localhost',
    'port': 6379,
    'db': 5,
    'decode_responses':True,
    'password':'bfd3f0h6j1k7b4'
}

cache_time = 60*3
cache_time_cookie = 60 * 60
url_servicio = 'http://45.183.45.2/'
timeout = 555
data_usuario = {'username':'jovan','password':'Multifiber2020*'}